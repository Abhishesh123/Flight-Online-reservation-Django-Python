exec(open('setup/users_test.py').read())
exec(open('setup/group_permissions.py').read())
