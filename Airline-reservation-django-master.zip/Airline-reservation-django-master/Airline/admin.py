from django.contrib import admin
from Airline.models import *
# Register your models here.

admin.site.register(Travelling)
admin.site.register(Booking)